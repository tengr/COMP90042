COMP9004 Project 1
Ruichen Teng / tengr / 6678693
----------------------------------------------------------------------------------------------------------------------------------------------------------------
Setup:
build_load.py
This has a set of methods that builds the indicated inverted index and load up queries and answers from file

----------------------------------------------------------------------------------------------------------------------------------------------------------------
Running:
The names indicates what IR the program is for.
graph drawing and precision measuring is done in evaluation_ir.py and process_results.py

